import type { CapacitorConfig } from "@capacitor/cli";

const config: CapacitorConfig = {
  appId: "il.karengoldberg.crm",
  appName: "קארן גולדברג",
  webDir: "capacitor-www",
  server: {
    androidScheme: "https",
    iosScheme: "https",
  },
  ios: {
    contentInset: "automatic",
    preferredContentMode: "mobile",
    scheme: "KarenGoldberg",
  },
  plugins: {
    StatusBar: {
      style: "DARK",
      backgroundColor: "#06070B",
    },
  },
};

export default config;
